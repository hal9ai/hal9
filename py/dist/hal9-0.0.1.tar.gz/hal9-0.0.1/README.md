# bussin

CDesign Interactive Data Apps Without Web Dev

## Installation

```bash
$ pip install bussin
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`bussin` was created by Anchit Sadnaa. It is licensed under the terms of the MIT license.

## Credits

`bussin` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
